#!/usr/bin/perl
use Net::Telnet; 

$telnet = new Net::Telnet ( Timeout=>10, Errmode=>'die'); 
$telnet->open(Host => 'localhost', Port => '5000');
@answer = $telnet->print("asfasdf");
print @answer;
@answer = $telnet->cmd("end");
