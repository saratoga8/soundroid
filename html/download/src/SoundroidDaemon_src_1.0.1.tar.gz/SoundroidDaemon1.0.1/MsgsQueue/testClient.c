#include "MsgsQueueClient.h"

#include <stdio.h>
#include <stdlib.h>
#include <errno.h>
#include <string.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/msg.h>

struct my_msgbuf {
    long mtype;
    char mtext[200];
};

int main(void)
{
    if(!initQueueClient())
	printf("ERROR: Can't init queue for client\n");
    
    printf("Enter lines of text, ^D to quit:\n");

    struct my_msgbuf buf;
    
    while(fgets(buf.mtext, sizeof buf.mtext, stdin) != NULL) {
        int len = strlen(buf.mtext);

        /* ditch newline at end, if it exists */
        if (buf.mtext[len-1] == '\n') buf.mtext[len-1] = '\0';

	sendMsgClient(buf.mtext);
	char* txt = receiveMsgClient();
        printf("answer: \"%s\"\n", txt);
    }


    return 0;
}
