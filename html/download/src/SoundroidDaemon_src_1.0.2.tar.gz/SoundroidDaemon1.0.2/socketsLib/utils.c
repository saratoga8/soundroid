/**
 * @file
 * Utils for writing errors to the log file
 *
 **
 * The MIT License (MIT)
 *
 * Copyright (c) 2014 Daniel Haimov
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */

#include "utils.h"

#include <stdlib.h>
#include <string.h>
#include <errno.h>

#include "Log.h"

#define TAG "UTILS" /**< tag for writing to log file */

/**
 * Write error string to the log file
 * @param result The result index, if result is error then the given error string should be written to the log file
 * @param funcName The name of the function where the error has taken place
 * @param errorStr The error string should be written to the log file
 */
void writeToLogIfError(const int result, const char *funcName, const char *errorStr)
{
    if (result == ERR)
    {
	#define ERRSTR "\tERROR: "
    	size_t len = strlen(ERRSTR) + strlen(funcName) + strlen(errorStr) + 1;
    	char *str = (char*) calloc(sizeof(char), len);
    	strcat(str, ERRSTR);
    	strcat(str, funcName);
    	strcat(str, errorStr);
	strcat(str, "\n");
        writeToLog(str, TAG);
	free(str);
    }
}

/*
void writeToLogIfFileOperationErr(const char *filePath, const char *errStr)
{
    char *err_explanation = strerror(errno);

    size_t len = strlen(err_explanation) + strlen(errStr) + strlen(filePath) + 4;
    char *str = (char*) calloc(sizeof(char), len);
    sprintf(str, "%s %s: %s", errStr, filePath, err_explanation);
    writeToLogIfError(ERR, "get_net_interface_name(): ", str);
    free(str);    
    }
*/
