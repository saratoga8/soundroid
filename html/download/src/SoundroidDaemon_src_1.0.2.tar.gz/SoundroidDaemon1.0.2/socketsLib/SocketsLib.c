/**
 * @file
 * The library for connecting by sockets
 * \var mutexData
 * \brief The mutex for sent/received data
 * \var mutexStop 
 * \brief The mutex for run status
 * \def DATA_LEN
 * \brief The length of the sent/received data array
 *
 **
 * The MIT License (MIT)
 *
 * Copyright (c) 2014 Daniel Haimov
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */

#include "SocketsLib.h"

#include <errno.h>

#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>
#include <ctype.h>

#include <sys/socket.h> 
#include <sys/types.h>
#include <netdb.h>
#include <net/if.h>
#include <arpa/inet.h>
#include <sys/ioctl.h>

#include <pthread.h>

#include "Log.h"
#include "IpOps.h"


pthread_mutex_t mutexData;     
pthread_mutex_t mutexStop;

int runStatus = RUN;

#define DATA_LEN 50                        
char receivedData[DATA_LEN] = {'\0'};
int  receivedDataStatus = NO_NEW_DATA;

char sentData[DATA_LEN] = {'\0'};

#define MAX_SOCKETS_NUM_WAITED_FOR_ACCEPT 5

#define STR_END "end"

#define TAG "SOCKETS_LIB"                  /**< The tag for writing to the log file */

#define IP_ADDR_STR_LEN 20                      /**< The length of the IP string */
char connectedIP[IP_ADDR_STR_LEN] = {'\0'};
char localIP    [IP_ADDR_STR_LEN] = {'\0'};

#define PORT_NUM_LEN 10                         /**< The length of the port number string */
char portNum[PORT_NUM_LEN] = {'\0'};


/*
void writeToLog2(const char* txt1, const char* txt2)
{
    #define BUFF_LEN 100
    char buff[BUFF_LEN] = {'\0'};
    if(sprintf(buff, txt1, txt2) < 0)
	{
	    printf("ERROR: can't copy the texts '%s", txt1);
	    printf("' and '%s", txt2);
	    printf("' to the buffer with the size %d\n", BUFF_LEN);
	    return;
	}
    writeToLog(buff, TAG);
    }*/

/**
 * Get the string of the last error
 * @return The string of the last error
 */
const char* getErrStr()
{
	return strerror(errno);
}

/**
 * Get local IP
 * @return The string of the local IP or ""
 */
const char* getLocalIP()
{
    return localIP;
}

/**
 * Get connected IP
 * @return The string of the connected IP or ""
 */
const char* getConnectedIP()
{
    return connectedIP;
}

/**
 * Set port number
 * @param port The port number string
 * @return ERR or NO_ERR
 */
const int setPort(const char* port)
{
    char buff[50] = {'\0'};
    if(port == NULL)
	{
	    writeToLog("ERROR setPort(): the given pointer to a port number string is NULL\n", TAG);
	    return ERR;
	}
    const size_t len = strlen(port);
    if(len == 0)
	{
	    writeToLog("ERROR setPort(): the given string of a port number is EMPTY\n", TAG);
	    return ERR;
	}
    if(len >= PORT_NUM_LEN)
	{
    	char err[100] = {'\0'};
	    sprintf(err, "ERROR setPort(): can't change the port. The LENGTH of the given port number %s is greater then %d", port, PORT_NUM_LEN);
	    writeToLog(err, TAG);
	    return ERR;
	}

    bzero(buff, strlen(buff));
    sprintf(buff, "\tChanging port from %s to %s\n", portNum, port);
    writeToLog(buff, TAG);

    if(strlen(portNum))
	bzero(portNum, PORT_NUM_LEN);

    strcpy(portNum, port);

    return NO_ERR;
}

/**
 * Get the currently used port
 * @return the string of the currently used port number
 */
char* getPort() 
{ 
  return portNum; 
}

/**
 * Check wether the given string is number
 * @param str The string for checking
 * @return true The string is number
 */
bool isStrNum(const char *str)
{
    if(str == NULL)
	{
	    writeToLog("ERROR: isStrNum(): the given string is NULL", TAG);
	    return false;
	}
    size_t len = strlen(str);
    if(len == 0)
	{
	    writeToLog("ERROR: isStrNum(): the given string is empty", TAG);
	    return false;	    
	}
    int i;
    for(i = 0; i < len; ++i)
	{
	    if(!isdigit(str[i]))
		{
		    writeToLog2("ERROR: isStrNum(): the given string contains a non-digit character. The string: ", str, TAG);
		    return false;
		}
	}
    return true;
}

/**
 * Fill the structures of a host info
 * @param host_info The host info structure, which should be filled up
 * @param host_info_list The list of the host info structs
 * @return The result: ERR or NO_ERR
 */
const int fillHostInfoStructs(struct addrinfo *host_info, struct addrinfo **host_info_list)
{
    writeToLog("Setting up the structs...\n", TAG);

    host_info->ai_family   = AF_UNSPEC;     // IP version not specified. Can be both.
    host_info->ai_socktype = SOCK_STREAM;   // Use SOCK_STREAM for TCP or SOCK_DGRAM for UDP.
    host_info->ai_flags    = AI_PASSIVE;    // IP Wildcard

    if(!isStrNum(portNum))
	return ERR;
	
    const int status = getaddrinfo(NULL, portNum, host_info, host_info_list);

    if (status != NO_ERR)
	writeToLog2("\tERROR fillHostInfoStructs(): ", gai_strerror(status), TAG);

    return status;
}

/**
 * Create socket from the given list of the host info structs
 * @param host_info_list The list of the host info structs
 * @return The socket descriptor
 */
const int createSocket(struct addrinfo *host_info_list)
{
    writeToLog("Creating a socket...\n", TAG);
    
    const int socketfd = socket(host_info_list->ai_family, host_info_list->ai_socktype,
                                host_info_list->ai_protocol);
    //    if (socketfd == ERR)
    //	writeToLog2("\tERROR createSocket(): ", strerror(errno), TAG);
    writeToLogIfError(socketfd, "createSocket(): ", strerror(errno));
    
    return socketfd;
}

/**
 * Bind the socket with the given descriptor
 * @param host_info_list The list of the host info structs
 * @param sockDescr The socket descriptor
 * @return The status of binding
 */
const int bindSocket(const int sockDescr, struct addrinfo *host_info_list)
{
    writeToLog("Binding socket...\n", TAG);

    int yes = 1;
    int status = setsockopt(sockDescr, SOL_SOCKET, SO_REUSEADDR, &yes, sizeof(int));
    if (status == ERR)
	{
	    writeToLog("\tERROR bindSocket(): %s\n", gai_strerror(status));
	    return status;
	}

    //    struct timeval timeout;      
    //    timeout.tv_sec = SOCKET_TIME_OUT;
    //    timeout.tv_usec = 0;

    //    status = setsockopt(sockDescr, SOL_SOCKET, SO_RCVTIMEO, (char *)&timeout, sizeof(timeout));
    //    if (status < 0)
    //	{
    //	    writeToLog2("\tERROR bindSocket(): ", gai_strerror(status), TAG);
    //	    return status;
    //	}

    status = bind(sockDescr, host_info_list->ai_addr, host_info_list->ai_addrlen);
    //    if (status == ERR)
    //	writeToLog2("\tERROR bindSocket(): ", gai_strerror(status), TAG);
    writeToLogIfError(status, "bindSocket(): ", gai_strerror(status));

    return status;
}

/**
 * Listen to new connections
 * @param sockDescr A socket's descriptor
 * @return ERR if there is an error. Any other number if there is no error
 */
const int listenConns(const int sockDescr)
{
    writeToLog("Listening for connections...\n", TAG);

    const int status =  listen(sockDescr, MAX_SOCKETS_NUM_WAITED_FOR_ACCEPT);
    //    if (status == ERR)
    //    	writeToLog2("\tERROR listenConns(): ", strerror(errno), TAG);
    writeToLogIfError(status, "listenConns(): ", strerror(errno));
    
    return status;
}

/**
 * Accept a connection
 * @param sockDescr A socket's descriptor
 * @return ERR if there is an error. Any other number if there is no error
 */
const int acceptConn(const int sockDescr)
{
    struct sockaddr_storage their_addr;
    
    socklen_t addr_size = sizeof(their_addr);
    const int newSockDescr = accept(sockDescr, (struct sockaddr *)&their_addr, &addr_size);

    //    if (newSockDescr == ERR)
    //        writeToLog2("\tERROR acceptConn(): ", strerror(errno), TAG);
    writeToLogIfError(newSockDescr, "acceptConn(): ", strerror(errno));

    return newSockDescr;
}

/**
 * Receive a data from a client
 * @param newSockDescr A socket's descriptor
 * @param incoming_data_buffer The buffer for incoming data
 * @param buff_len The length of the buffer
 * @return The buffer of the incoming data or NULL if there is an error
 */
const char* receiveData(const int newSockDescr, char* incoming_data_buffer, const size_t buff_len)
{
    if(incoming_data_buffer == NULL)
      {
	  writeToLog("ERROR receiveData(): The given pointer to buffer for incoming data is NULL\n", TAG);
	  return NULL;
      }
    if(buff_len == 0)
      {
	  writeToLog("ERROR receiveData(): The length of the given buffer is 0\n", TAG);
	return NULL;
      }

    if(buff_len != 0)
	bzero(incoming_data_buffer, buff_len);
    
    writeToLog("Waiting to receive data...\n", TAG);

    ssize_t bytes_recieved = recv(newSockDescr, incoming_data_buffer, buff_len, 0);
    
    if (bytes_recieved == 0)
	{
	    writeToLog("\tHost shut down.\n", TAG);
	    return STR_END;
	}
    if (bytes_recieved == ERR) 
      {
	  writeToLog2("\tERROR receiveData(): ", strerror(errno), TAG);
	  return NULL;
      }
    
    incoming_data_buffer[bytes_recieved - 2] = '\0';    // remove EOL

    return incoming_data_buffer;
}

/**
 * Send data by sockets.
 * @param socketDescr The socket descriptor
 * @return ERR or NO_ERR
 */
const int sendData(const int socketDescr)
{
    writeToLog2("Sending the answer: ", sentData, TAG);

    const size_t sentDataLen = strlen(sentData);
    const ssize_t bytes_sent = send(socketDescr, sentData, sentDataLen, 0);

    bzero(sentData, sentDataLen);
    
    if(bytes_sent == ERR)
	{
	    writeToLog2("\tERROR sendData(): ", strerror(errno), TAG);
	    return ERR;
	}

    if(bytes_sent != sentDataLen)
	{
	    writeToLog("\tERROR sendData(): The data hasn't sent successfully. The size of the sent data doesn't equal the actual data's size\n", TAG);
	    return ERR;
	}

    return NO_ERR;
}   

/**
 * Set the status of the recieved data
 * @param status HAS_NEW_DATA or NO_NEW_DATA
 */
void setReceivedDataStatus(const int status) 
{
    pthread_mutex_lock (&mutexData);
    receivedDataStatus = status;
    pthread_mutex_unlock(&mutexData);
}

/**
 * Client-server conversation
 * @param incoming_data_buffer The string buffer for the incoming from the client data
 * @param buff_len The length of the buffer
 * @param socketDescr The socket descriptor of the conversation
 * @return The integer status of the conversation: ERR, NO_ERR or STOP if received the connection
 *                                                                     end message
 */
const int conversation(char *incoming_data_buffer, const size_t buff_len, const int socketDescr)
{
    if(incoming_data_buffer == NULL)
      {
	  writeToLog("ERROR conversation(): The given pointer to buffer for incoming data is NULL\n", TAG);
	  return ERR;
      }
    if(buff_len == 0)
      {
	  writeToLog("ERROR conversation(): The length of the given buffer is 0\n", TAG);
	  return ERR;
      }

    const char* str = receiveData(socketDescr, incoming_data_buffer, buff_len);
    if(str == NULL)
	return ERR;
    if(strcmp(str, STR_END) == 0)
        return STOP;

    writeToLog2("\tReceived string: ", incoming_data_buffer, TAG);
 
    strcpy(receivedData, incoming_data_buffer);

    setReceivedDataStatus(HAS_NEW_DATA);
    
    while(strlen(sentData) == 0);   // waiting for the input of the data for sending
    return sendData(socketDescr);    
}

/**
 * Close the socket connection
 * @param sockDescr The socket descriptor of the connection
 * @return The result integer of closing
 */
const int closeSocketConn(const int sockDescr)
{
    if(sockDescr <= 0)
	return ERR;
	
    writeToLog("\tClosing socket connection\n", TAG);

    const int res = close(sockDescr);
    if(res == ERR)
	writeToLog2("\tERROR closeSocketConn(): ", strerror(errno), TAG);

    return res;
}

/**
 * Destroy mutexes
 */
void destroyMutexes()
{
    pthread_mutex_destroy(&mutexStop);
    pthread_mutex_destroy(&mutexData);
}

/**
 * Initialize mutexes
 */
void initMutexes()
{
    pthread_mutex_init(&mutexStop, NULL);
    pthread_mutex_init(&mutexData, NULL);    
}

/**
 * Initial connection before listening
 * @return socket descriptor or ERR
 */
const int initConnectionBeforeListen()
{
    struct addrinfo host_info;       // The struct that getaddrinfo() fills up with data.
    struct addrinfo *host_info_list; // Pointer to the to the linked list of host_info's.
    memset(&host_info, 0, sizeof host_info);

    int sockDescr = ERR;
    if(fillHostInfoStructs(&host_info, &host_info_list) != ERR)
	{
	    sockDescr = createSocket(host_info_list);
	    if(sockDescr != ERR)
		{
		    if (bindSocket(sockDescr, host_info_list) != ERR)
		    {
			    bzero(localIP, IP_ADDR_STR_LEN);
			    copyLocalIp2Str(localIP);
		    }
		    else
		    {
		    	closeSocketConn(sockDescr);
		    	sockDescr = ERR;
		    }
		}
	}

    freeaddrinfo(host_info_list);
    return sockDescr;
}

/**
 * Run client-server connection
 */
void runConnection(const int sockDescr)
{
	if(sockDescr == ERR)
		return;

    initMutexes();

    while( (runStatus != STOP))
    {
    	if (listenConns(sockDescr) != ERR)
    	{
    		const int newSockDescr = acceptConn(sockDescr);
    		if(newSockDescr != ERR)
    		{
    			bzero(connectedIP, IP_ADDR_STR_LEN);
    			copyConnectedIp2Str(newSockDescr, connectedIP);

    			char receivedDataArr[DATA_LEN] = {'\0'};

    			while(conversation(receivedDataArr, DATA_LEN, newSockDescr) == NO_ERR);

    			if(closeSocketConn(newSockDescr) == ERR)
    				break;
    		}
    	}
    }
    
    closeSocketConn(sockDescr);

    destroyMutexes();    
}

/**
 * Set data string for sending
 * @param dataStr data string
 */
void setSentData(const char *dataStr)
{
    if(strlen(sentData) != 0)
	bzero(sentData, DATA_LEN);
    strcpy(sentData, dataStr);
}

/**
 * Get the deceived data string
 * @return The received data string
 */
char* getReceivedData() 
{
    pthread_mutex_lock(&mutexData);
    if(receivedDataStatus == HAS_NEW_DATA)
	{
	    receivedDataStatus = NO_NEW_DATA;
	    pthread_mutex_unlock(&mutexData);
	    return receivedData;
	}
    pthread_mutex_unlock(&mutexData);
    return "";
}

/**
 * Set the status of running
 * @param status The status: RUN or STOP
 */
void setRunStatus(const int status)
{
    pthread_mutex_lock (&mutexStop);
    runStatus = status;
    pthread_mutex_unlock(&mutexStop);
}

/**
 * Get the status of running
 * @return The status: RUN or STOP
 */
const int getRunStatus()
{
	int cur_status = STOP;
    pthread_mutex_lock (&mutexStop);
    cur_status = runStatus;
    pthread_mutex_unlock(&mutexStop);
    return cur_status;
}


