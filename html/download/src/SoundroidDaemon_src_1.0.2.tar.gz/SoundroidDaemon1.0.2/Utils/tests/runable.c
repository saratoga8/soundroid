#include <stdio.h>

int main(int argc, char* argv[])
{
    FILE *file = fopen(argv[1], "w");
    if (file == NULL)
	{
	    printf("ERROR: Can't open file %s\n", argv[1]);
	    return 1;
	}
    fprintf(file, "string from file\n");
    fclose(file);
    
    return 0;
}
