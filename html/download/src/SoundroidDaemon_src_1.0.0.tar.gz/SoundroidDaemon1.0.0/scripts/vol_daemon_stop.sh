#!/bin/sh
FILE=pid.txt
PID=0
SIGNAL=15    # SIGTERM
PROG_NAME=vol_daemon

THIS_PROG_NAME=`echo $0 | sed -s 's/\.sh//' | sed -s 's/\.\///'`

SUCCESS=0
FAILED=-1
RESULT=$SUCCESS

STR=`ps -e | grep $PROG_NAME | awk '{print $4}' | grep -Fx "$PROG_NAME"`
if [ -z "$STR" ]; then
    echo "The distance sound control daemon isn't running"
    [ -e $FILE ] && rm -f $FILE
    exit $SUCCESS;
fi 

if [ -e $FILE ]; then 
    PID=`cat $FILE`
#    echo "Killing the daemon by sending signal..."
    kill -s $SIGNAL $PID
    sleep 1
fi

STR=`ps -e | grep $PROG_NAME | awk '{print $4}' | grep -Fx "$PROG_NAME"`
if [ -n "$STR" ]; then
    echo "WARNING: Killing the daemon by command 'killall'"
    killall $PROG_NAME
fi

STR=`ps -e | grep $PROG_NAME | awk '{print $4}' | grep -Fx "$PROG_NAME"`
if [ -n "$STR" ]; then
    echo "ERROR: Can't close the daemon $PROG_NAME!"
    RESULT=$FAILED
fi

[ -e $FILE ] && rm -f $FILE
exit $RESULT
