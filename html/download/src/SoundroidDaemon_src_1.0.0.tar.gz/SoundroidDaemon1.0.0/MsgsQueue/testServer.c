#include "MsgsQueueServer.h"
#include "Log.h"
#include <unistd.h>
#include <string.h>
#include <pthread.h>

void *run()
{
    runQueue();
}

int main(int argc, char* argv[])
{
    openLogFile("log.txt");
	
    initQueueServer();
    
    pthread_t thread;
    int res = 0;
    if ( res = pthread_create(&thread, NULL, run, NULL) )
	{
	    printf("ERROR; return code from pthread_create() is %d\n", res);
	    return -1;
	}

   char *str;
    while(str = receiveMsgServer())
	{
	    if(strlen(str))
		{
		    printf("Received: %s\n", str);
		    sendMsgServer("test");
		    if(strcmp(str, "end") == 0)
		       break;
		}
	}

    deleteQueue();

    pthread_exit(NULL);

    closeLogFile();
    return 0;
}
