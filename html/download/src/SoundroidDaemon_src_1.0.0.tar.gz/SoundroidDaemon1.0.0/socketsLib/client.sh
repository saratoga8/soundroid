#!/usr/bin/expect -f

spawn telnet localhost 5000
set timeout 60

expect {
    "Connection refused" exit
    "Escape character"
}

send "one\n"
expect {
    sleep 5
    timeout { puts "the answer hasn't arrived\n"; exit }
    "test"
}
send "two\n"
expect {
    sleep 5
    timeout { puts "the answer hasn't arrived\n"; exit }
    "test"
}
send "quit\n"
expect {
    sleep 5
    timeout { puts "the answer hasn't arrived\n"; exit }
    "test"
}
exit
