/**
 * @file
 * The library for connecting by sockets
 *
 **
 * The MIT License (MIT)
 *
 * Copyright (c) 2014 Daniel Haimov
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */

#ifndef SOCKETS_LIB_H
#define SOCKETS_LIB_H

#include "utils.h"


#define SOCKET_TIME_OUT 60   /**< Sockets connection time out in seconds */

#define NO_NEW_DATA  0
#define HAS_NEW_DATA 1

#define RUN  2   /**< The connection is running */
#define STOP 3   /**< The connection is stopped */

/**
 * Set the status of running
 * @param status The status: RUN or STOP
 */
void setRunStatus(const int status);      

/**
 * Get the status of running
 * @return The status: RUN or STOP
 */
const int getRunStatus();

/**
 * Set data string for sending
 * @param dataStr data string
 */
void setSentData(const char *dataStr);    

/**
 * Initial connection before listening
 * @return socket descriptor or ERR
 */
const int initConnectionBeforeListen();

/**
 * Run client-server connection
 * @param sockDescr The socket descriptor
 */
void runConnection(const int sockDescr);

/**
 * Get the deceived data string
 * @return The received data string
 */
char* getReceivedData();

/**
 * Set the status of the recieved data
 * @param status HAS_NEW_DATA or NO_NEW_DATA
 */
void setReceivedDataStatus(const int stat);     

/**
 * Get local IP
 * @return The string of the local IP or ""
 */
const char* getLocalIP();

/**
 * Get connected IP
 * @return The string of the connected IP or ""
 */
const char* getConnectedIP();

/**
 * Set port number
 * @param port The port number string
 * @return ERR or NO_ERR
 */
const int setPort(const char* port);

/**
 * Get the string of the last error
 * @return The string of the last error
 */
const char* getErrStr();

#endif

