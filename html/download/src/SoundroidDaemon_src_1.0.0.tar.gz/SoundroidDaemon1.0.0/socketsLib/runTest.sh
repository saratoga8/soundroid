#!/bin/bash

RED='\e[0;31m'
GREEN='\e[0;32m'
NC='\e[0m'

STR_WITH_IP=`ifconfig | grep 'inet addr' | grep -v 127.0.0.1 | head -n 1`
IP=`echo $STR_WITH_IP | sed 's/inet addr:'// | awk '{print $1}'`

if [ -e test.correct ]; then
    `sed -i "s/Local IP:.*/Local IP: $IP/" test.correct`
fi

rm -f log.txt *.out

echo "Running programs..."
./test 5000 1> test.out &
./client.sh 1> client.out

echo "Analysing results..."

diff_res=`diff client.out client.correct`
if [ -n "$diff_res" ]; then
    echo -e "\tAnalysing client's result...${RED}FAILED${NC}"
else
    echo -e "\tAnalysing client's result...${GREEN}PASSED${NC}"
fi

diff_res=`diff test.out test.correct`
if [ -n "$diff_res" ]; then
    echo -e "\tAnalysing test's result.....${RED}FAILED${NC}"
else
    echo -e "\tAnalysing test's result.....${GEEN}PASSED${NC}"
fi


