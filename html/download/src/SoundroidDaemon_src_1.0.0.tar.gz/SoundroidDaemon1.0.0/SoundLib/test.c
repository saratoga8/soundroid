#include "SoundLib.h"
#include <stdlib.h>
#include <stdio.h>

#include "Log.h"

int main(int argc, char* argv[])
{
    openLogFile("log.txt");
    
    switch(atoi(argv[1]))
	{
	  case 0:
	      mute(); break;
	  case 1:
	      unmute(); break;
	  case 2:
	      printf("Vol: %ld\n", getVol());
	      chgVol(5);
	      printf("Vol: %ld\n", getVol());
	      break;
	  case 3:
	      printf("Vol: %ld\n", getVol());
	      chgVol(-5);
	      printf("Vol: %ld\n", getVol());
	      break;
	}

    closeLogFile();
    
    return 0;
}
