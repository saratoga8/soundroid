#include "file_utils.h"
#include "str_utils.h"
#include <stdio.h>

#define RED         "\x1B[31m"
#define GRN         "\x1B[32m"
#define COLOR_RESET "\x1b[0m"

int main(int argc, char* argv[])
{
    isStrEmptyOrNULL(NULL, __FILE__, __LINE__);
    /*
    char *fileName = argv[0];
    printf("Test existance of the file %s...", fileName);
    
    doesDirHasFile(".", fileName) ? printf("%sPASSED%s\n", GRN, COLOR_RESET): printf("%sFAILED%s\n", RED, COLOR_RESET);

    fileName = argv[1];
    printf("Test running of the file %s...\n", fileName);
    runFileInCurDir(fileName, "");
    */
    
    return 0;
}
