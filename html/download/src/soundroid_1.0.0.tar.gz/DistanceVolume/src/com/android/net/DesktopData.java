/**
 * @file
 * A desktop data.
 * The desktop data is the data about the computer the application connects to for changing sound volume
 * of the desktop.
 * The desktop data consists of the desktop's IP, the port number of the daemon running on the desktop
 * and the desktop's name, given by user
 */
package com.android.net;

import java.io.Serializable;
import java.security.InvalidParameterException;

import android.text.TextUtils;

/**
 * The data of the desktop and operations with it 
 */
public class DesktopData implements Serializable {
	private static final long serialVersionUID = 1L;
	
	private String name;     /**< The desktop's name, given by user*/
	private String ip;       /**< The IP of the desktop */
	private String port;     /**< The port number of the daemon, running on the desktop */
	
	/**
	 * Constructor initializing desktop's data
	 * @param name The name of the desktop
	 * @param ip The desktop's IP
	 * @param port The port number of the daemon on the desktop
	 */
	public DesktopData(String name, String ip, String port) {
		if(TextUtils.isEmpty(name)) {
			throw new InvalidParameterException("The given desktop's name is NULL or EMPTY");
		}
		if(TextUtils.isEmpty(ip)) {
			throw new InvalidParameterException("The given desktop's ip is NULL or EMPTY");
		}
		if(TextUtils.isEmpty(port)) {
			throw new InvalidParameterException("The given desktop's port is NULL or EMPTY");
		}
		
		this.name = name;
		
		chkIP(ip);
		this.ip = ip;
		
		try {
			Integer.parseInt(port);
			this.port = port;
		}
		catch (NumberFormatException e) {
			throw new InvalidParameterException("The given port '" + port + "' doesn't contain number");
		}
	}
	
	/**
	 * Constructor initializing a desktop data from the given string
	 * @param data The string with desktop's data
	 */
	public DesktopData(String data) {
		if(TextUtils.isEmpty(data)) {
			throw new InvalidParameterException("The given desktop's data string is NULL or EMPTY");
		}
		
		String arr[] = data.split(",");
		try {
			name = arr[0];
		} 
		catch (ArrayIndexOutOfBoundsException e) {
			throw new InvalidParameterException("The given desktop's data string '" + data + "' doesn't contain the desktop's name");
		}
		try {
			ip = arr[1];
		} 
		catch (ArrayIndexOutOfBoundsException e) {
			throw new InvalidParameterException("The given desktop's data string '" + data + "' doesn't contain the desktop's IP");
		}
		try {
			port = arr[2];
		} 
		catch (ArrayIndexOutOfBoundsException e) {
			throw new InvalidParameterException("The given desktop's data string '" + data + "' doesn't contain the desktop's port");
		}
	}
	
	/**
	 * Build the desktop data containing empty IP, name and name
	 * @return The empty desktop data instance
	 */
	public static DesktopData buildEmptyDesktopData() {
		DesktopData empty = new DesktopData(" , , ");
		empty.setName("");
		empty.setIP("");
		empty.setPort("");
		
		return empty;
	}
	
	/**
	 * Get desktop's name
	 * @return The desktop's name
	 */
	public String getName() {
		return name;
	}
	
	/**
	 * Get desktop's IP 
	 * @return The desktop's IP
	 */
	public String getIP() {
		return ip;
	}
	
	/**
	 * Get the port number of the daemon running on the desktop
	 * @return The port number
	 */
	public String getPort() {
		return port;
	}
	
	@Override
	/**
	 * Get desktop's data in string
	 * @return The string of the desktop's data
	 */
	public String toString() {
		return name + "," + ip + "," + port;
	}

	/**
	 * Set desktop's name
	 * @param name The desktop's new name
	 */
	public void setName(String name) {
		if (name == null) {
			throw new NullPointerException("The given parameter name is NULL");
		}
		this.name = name;
	}

	/**
	 * Set desktop's IP
	 * @param ip The desktop's new IP
	 */
	public void setIP(String ip) {
		if (ip == null) {
			throw new NullPointerException("The given parameter ip is NULL");
		}
		this.ip = ip;
	}

	/**
	 * Set the desktop's port number 
	 * @param port The desktop's new port
	 */
	public void setPort(String port) {
		if (port == null) {
			throw new NullPointerException("The given parameter port is NULL");
		}
		this.port = port;
	}
	
	/**
	 * Check the given string is IP address
	 * @param ipStr The IP string 
	 */
	private void chkIP(String ipStr) {
		String arr[] = ipStr.split("\\.");
		if(arr.length != 4) {
			throw new InvalidParameterException("The size of the IP address " + ipStr + " is not 4 numbers");
		}
		for(String numStr: arr) {
			try {
				final int num = Integer.parseInt(numStr);
				if(num > 255) {
					throw new InvalidParameterException("The IP address contains number " + numStr + " which is more than 255");
				}
			}
			catch (NumberFormatException e) {
				throw new InvalidParameterException("The IP address " + numStr + " contains non-number characters");
			}
		}
	}

	/**
	 * Get the IP as a strings array 
	 * @return The array of strings
	 */
	public String[] getIpArr() {
		if(ip.length() == 0) {
			return new String[4];
		}
		
		return ip.split("\\.");
	}
	
	/**
	 * Is the desktop's data empty?
	 * @return true The data is empty
	 */
	public boolean isEmpty() {
		if(name.length() == 0) {
			if(ip.length() == 0) {
				return (port.length() == 0);
			}
		}
		return false;
	}
}
