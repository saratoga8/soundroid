/**
 * Utils for work with files
 */
package com.android.others;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.List;

import android.content.Context;
import android.text.TextUtils;

import com.android.net.DesktopData;

/**
 * Utils for work with files
 */
public abstract class FileUtils {
	
	/**
	 * Get one string from the file with the given name
	 * @param context The app's context instance
	 * @param fileName The file name for reading
	 * @return The read string from the file
	 * @throws IOException
	 */
	public static String getOneLineFromFile(final Context context, String fileName) throws IOException {
		if (TextUtils.isEmpty(fileName)) {
			throw new NullPointerException("The given parameter 'fileName' is NULL or EMPTY");
		}
		
		FileInputStream inputStream = null;
		BufferedReader bufferedReader = null;
		try {
			inputStream  = context.openFileInput(fileName);
			bufferedReader = new BufferedReader(new InputStreamReader(inputStream));

			String line = bufferedReader.readLine();

			return (line != null) ? line: "";
			
		} catch (IOException e) {
			throw new IOException("Can't read the file " + fileName + ": " + e.toString());
		}
		finally {
			closeBufferReaderAndInputStream(inputStream, bufferedReader);
		}
	}

	/**
	 * Close the buffer of reader and input stream
	 * @param inputStream The input stream instance
	 * @param bufferedReader The buffer reader instance
	 * @throws IOException
	 */
	private static void closeBufferReaderAndInputStream(final FileInputStream inputStream, final BufferedReader bufferedReader)	throws IOException {
		if(bufferedReader != null) {
			try {
				bufferedReader.close();
			} catch (IOException e) {
				throw new IOException("Can't close the buffer reader instance: " + e.toString());
			}
		}
		if(inputStream != null) {
			try {
				inputStream.close();
			} catch (IOException e) {
				throw new IOException("Can't close the file input stream instance: " + e.toString());
			}
		}
	}
	
	/**
	 * Get lines from the file with the given name
	 * @param context The app's context
	 * @param fileName The name of the file
	 * @return The array list of the string from the file
	 * @throws IOException
	 */
	public static ArrayList<String> getLinesFromFile(final Context context, String fileName) throws IOException {
		if (TextUtils.isEmpty(fileName)) {
			throw new NullPointerException("The given parameter 'fileName' is NULL or EMPTY");
		}
		
		FileInputStream inputStream = null;
		BufferedReader bufferedReader = null;

		try {
			inputStream  = context.openFileInput(fileName);
			bufferedReader = new BufferedReader(new InputStreamReader(inputStream));
			String line = null;
			ArrayList<String> names = new ArrayList<String>();  
			while( (line = bufferedReader.readLine()) != null ) {
				names.add(line);
			}
			return names;
			
		} catch (IOException e) {
			throw new IOException("Can't read the file " + fileName + ": " + e.toString());
		}
		finally {
			closeBufferReaderAndInputStream(inputStream, bufferedReader);
		}
	}
	
	/**
	 * Save the given data string to the file with the given name
	 * @param context The app's context
	 * @param fileName The file name
	 * @param data The data string 
	 * @param mode The mode of saving(adding or rewriting)
	 * @throws IOException
	 */
	public static void saveDataStr(final Context context, String fileName, String data, final int mode) throws IOException {
		if (TextUtils.isEmpty(fileName)) {
			throw new NullPointerException("The given parameter 'fileName' is NULL or EMPTY");
		}
		
		if(TextUtils.isEmpty(data)) {
			return;
		}
		
		FileOutputStream outputStream = null;
		try {
			outputStream  = context.openFileOutput(fileName, mode);
			outputStream.write(data.getBytes());
		} catch (Exception e) {
			throw new IOException("Cant write to the file " + fileName + ": " + e.toString());
		}
		finally {
			closeOutputStream(outputStream);
		}
	}
	
	/**
	 * Save data list to the file with the given name
	 * @param context The app's context
	 * @param fileName The file name
	 * @param data The list of the data for saving
	 * @throws IOException
	 */
	public static void saveDataList(final Context context, String fileName, List<DesktopData> data) throws IOException {
		if (TextUtils.isEmpty(fileName)) {
			throw new NullPointerException("The given parameter 'fileName' is NULL or EMPTY");
		}
		
		if (data == null) {
			throw new NullPointerException("The given parameter 'data' is NULL");
		}
		if(data.isEmpty()) {
			return;
		}
		
		StringBuilder txt = new StringBuilder();
		for(DesktopData curDesktopData: data) {
			txt = txt.append((curDesktopData.toString() + "\n"));
		}		
		
		FileOutputStream outputStream = null;
		try {
			outputStream  = context.openFileOutput(fileName, Context.MODE_PRIVATE);
			outputStream.write(txt.toString().getBytes());
		} catch (Exception e) {
			throw new IOException("Cant write to the file " + fileName + ": " + e.toString());
		}
		finally {
			closeOutputStream(outputStream);
		}
	}
	
	/**
	 * Close the output stream
	 * @param outputStream The output stream instance
	 * @throws IOException
	 */
	private static void closeOutputStream(OutputStream outputStream) throws IOException {
		if(outputStream != null) {
			try {
				outputStream.close();
			} catch (IOException e) {
				throw new IOException("Can't close the file output stream instance: " + e.toString());
			}
		}
	}
}
